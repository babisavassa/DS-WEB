## DS-WEB 

- 🔭 Estou cursando Desenvolvimento de Sistemas
- 🌱 Estou aprendendo desenvolvimento Web
- 📫 How to reach me: barbara.savassa16@gmail.com
- 😄 Pronouns: ela/dela
- ⚡ Fun fact: Python
